# Contributing to Task Orchestrator

Thank you for considering contributing! This project aims to be the best AI-agnostic task orchestrator — simple, robust, and cross-platform.

## Development Setup

```bash
# Clone the repository
git clone https://github.com/task-orchestrator/task-orchestrator.git
cd task-orchestrator

# Install in development mode
pip install -e .

# Run tests
python -m unittest discover -s tests

# Run linting (optional, requires ruff)
pip install ruff
ruff check src/
```

## Architecture

The project has two parallel codepaths during the v1→v2 transition:

- **`orchestrator.py`** — the original single-file orchestrator (still fully functional, backward-compatible)
- **`src/task_orchestrator/`** — the modular v2 package (installable via pip, same logic split into clean modules)

### Module Layout

| Module | Responsibility |
|--------|---------------|
| `cli.py` | Argument parsing, subcommands, entry point |
| `config.py` | Config loading, validation, env var interpolation, linting |
| `state.py` | Persistent state (cooldowns, durations), atomic writes |
| `todo.py` | Todo.md parsing, completion, section filtering |
| `provider.py` | Provider class, rate-limit tracking, subprocess execution |
| `git.py` | Git operations with transient-error retry |
| `platform.py` | Cross-platform: file locking, process kill, executable resolution |
| `notify.py` | Desktop notifications and audio cues |
| `logging.py` | Timestamped logging, JSON structured logs, rotation, secret masking |
| `init.py` | `task-orchestrator init` scaffolding command |

## Pull Request Process

1. Fork the repo and create a feature branch from `main`
2. Write tests for new functionality
3. Ensure `python -m unittest discover -s tests` passes on your platform
4. Keep changes focused — one feature or fix per PR
5. Update README/docs if you're adding user-facing features

## Code Style

- Python 3.9+ compatible (no walrus operator in hot paths, use `from __future__ import annotations`)
- Type hints on all public functions
- No external dependencies in core (stdlib only) — optional extras are fine for plugins/dev tools
- Use `ruff` for linting (config in `pyproject.toml`)

## Adding a New Provider Example

Add a JSON file to `examples/` with your provider config. Include:
- The exact `command` invocation
- Which `rate_limit_patterns` to use
- Any required `env` variables (use `$VAR_NAME` interpolation syntax)
- A brief comment explaining the setup

## Reporting Issues

- Include your OS, Python version, and agent CLI version
- Paste the relevant section of `logs/orchestrator.log`
- For rate-limit detection issues, include the CLI output that was/wasn't matched
