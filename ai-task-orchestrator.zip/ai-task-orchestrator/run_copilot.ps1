param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$ExtraArgs
)

$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

python orchestrator.py --config config.copilot.json @ExtraArgs
