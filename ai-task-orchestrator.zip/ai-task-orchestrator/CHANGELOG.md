# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.0.0] - 2026-07-24

### Added
- **Package structure**: installable via `pip install task-orchestrator` with CLI entry point
- **`task-orchestrator init`**: scaffolds config, Todo.md, prompt template, and .gitignore
- **`task-orchestrator validate`**: checks config, provider reachability, and git state
- **`--provider <name>`**: force a specific provider for a single run
- **`--task "text"`**: run a one-off task without editing Todo.md
- **`--dry-run-prompt`**: show the exact prompt that would be sent without executing
- **`--resume-from <text>`**: start from a specific task instead of the top
- **`--list-tasks / --peek`**: preview next N tasks with provider assignment
- **Environment variable interpolation**: `$VAR` and `${VAR}` in config values
- **Atomic state writes**: write-then-rename prevents corruption on crash
- **Secret masking**: API keys redacted from log output
- **Global config**: `~/.task-orchestrator/config.json` merged under project config
- **JSON Schema**: `config.schema.json` for IDE autocompletion
- **`on_failure` config**: choose `skip`, `defer`, or `stop` behavior
- **Dashboard `/health` endpoint**: returns 200 for external monitoring
- **Dashboard auto-refresh**: JavaScript polling replaces meta-refresh
- **Dashboard port fallback**: retries next port if configured port is busy
- **Graceful dashboard shutdown**: explicit `server.shutdown()` on exit
- **SIGTERM handling**: graceful shutdown for containers/systemd
- **No hard git dependency**: graceful degradation when not in a git repo
- **Cross-platform**: Windows file locking, process termination, executable resolution
- **PowerShell supervisor**: `run_forever.ps1` equivalent to `run_forever.sh`
- **Interactive commands**: p(ause), s(kip), q(uit), r(esume) during runs
- **Fun stats in summary**: longest/shortest task, success streak, verdict
- **Milestone celebrations**: notification every 10th task
- **Run report card**: printed on natural completion
- **GitHub Actions CI**: Python 3.9–3.13 on ubuntu/windows/macos
- **CONTRIBUTING.md**: development setup, architecture, PR process
- **Example configs**: copilot.json, claude.json, multi-provider.json
- **Type hints**: all public APIs fully typed

### Changed
- Main execution loop now lives in `src/task_orchestrator/runner.py`; top-level `orchestrator.py` is a compatibility shim
- Config `verify_commands` default uses `python` (not `python3`) for Windows compatibility
- Failed tasks are skipped in-memory by default instead of reordered in Todo.md
- Provider command resolution uses `shutil.which` + Windows suffix fallback
- `.ps1` provider commands auto-wrapped through pwsh

### Fixed
- `fcntl` import crash on Windows
- False stall detection on Windows (CPU sampling unavailable)
- Tests using `/tmp` and `python3` now cross-platform

## [1.0.0] - 2026-07-01

### Added
- Initial single-file orchestrator with multi-provider rotation
- Rate-limit detection and exponential backoff
- Activity-based stall detection
- Dashboard via stdlib http.server
- Verification gate and auto-commit
- Manual confirmation mode
