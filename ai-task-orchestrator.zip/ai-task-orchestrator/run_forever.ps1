param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$OrchestratorArgs
)

$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

while ($true) {
    python orchestrator.py @OrchestratorArgs
    $code = $LASTEXITCODE

    if ($code -eq 0) {
        Write-Host "[supervisor] Orchestrator finished normally (all tasks done, or stopped on purpose). Not restarting."
        break
    }
    elseif ($code -eq 130) {
        Write-Host "[supervisor] Interrupted by Ctrl+C. Not restarting."
        break
    }
    else {
        Write-Host "[supervisor] Orchestrator exited unexpectedly (code $code). Restarting in 10s..."
        Start-Sleep -Seconds 10
    }
}
