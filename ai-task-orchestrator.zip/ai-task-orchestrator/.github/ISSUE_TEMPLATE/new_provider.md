---
name: New Provider
about: Request or document support for a new agent CLI provider
title: "[Provider] "
labels: provider
---

**Provider Name**
(e.g. Aider, Continue, Tabby, etc.)

**CLI Command**
The exact command to invoke the agent non-interactively:
```
agent-cli --flag --model model-name
```

**Stdin or Arg-based Prompt?**
- [ ] Reads prompt from stdin
- [ ] Takes prompt as CLI argument (needs `{{TASK}}` in command)

**Rate Limit Patterns**
Substrings that appear in output when rate-limited:
```
rate limit
429
quota exceeded
```

**Required Environment Variables**
```
API_KEY=...
BASE_URL=...
```

**Notes**
Any special flags needed for non-interactive/unattended use, known quirks, etc.
