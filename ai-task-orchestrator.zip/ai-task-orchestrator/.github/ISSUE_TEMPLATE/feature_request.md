---
name: Feature Request
about: Suggest a new feature or improvement
title: "[Feature] "
labels: enhancement
---

**Problem / Use Case**
Describe the problem you're trying to solve or the workflow you want to improve.

**Proposed Solution**
How you'd like it to work (CLI flags, config options, behavior).

**Alternatives Considered**
Any workarounds you've tried or alternative approaches.

**Additional Context**
Links, screenshots, or examples from other tools.
