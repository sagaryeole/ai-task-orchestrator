---
name: Bug Report
about: Report a bug or unexpected behavior
title: "[Bug] "
labels: bug
---

**Environment**
- OS: (e.g. Windows 11, macOS 14, Ubuntu 24.04)
- Python version: (e.g. 3.12.4)
- task-orchestrator version: (run `task-orchestrator --version`)
- Agent CLI: (e.g. copilot 1.0.74, claude 1.2.0)

**Describe the bug**
A clear description of what happened vs. what you expected.

**Steps to reproduce**
1. Config used (sanitize API keys):
2. Command run:
3. Relevant Todo.md content:

**Log output**
Paste the relevant section of `logs/orchestrator.log`:

```
(paste here)
```

**Additional context**
Any other information (screenshots, related issues, etc.)
